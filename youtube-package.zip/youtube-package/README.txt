NOVA PRO HOME - YOUTUBE PACKAGE
Channel: https://www.youtube.com/@NovaProHome

HOW TO UPLOAD EACH VIDEO (YouTube Studio > Create > Upload videos):
1. Pick the .mp4 in the folder.  2. Paste TITLE and DESCRIPTION from upload_text.txt.
3. Thumbnail: upload thumbnail.jpg (long videos only; Shorts pick a frame).
4. Audience: 'No, it's not made for kids'.  5. Altered content: YES (AI voice / AI footage).
6. Visibility: Public (or Schedule).

SUGGESTED SCHEDULE: post 01 + 02 first, then one Short a day.

- 01_Channel_Intro: Ring & Google Nest Installation in Northern Virginia | Welcome to Nova Pro Home
- 02_How_to_Wire_a_Ring_Doorbell: How to Wire a Ring Doorbell (Step by Step Install) | Nova Pro Home
- 03_Short_where_to_put_security_cameras: Where Should Security Cameras Go? 3 Spots Every Home Needs #shorts
- 04_Short_battery_vs_wired_ring_doorbell: Battery vs Wired Ring Doorbell: Which Should You Get? #shorts
- 05_Short_ring_solar_panel_no_outlet: No Outlet for Your Camera? Use a Ring Solar Panel #shorts
- 06_Short_ring_doorbell_not_working_3_checks: Ring Doorbell Not Working? Check These 3 Things First #shorts
- 07_Short_nest_thermostat_compatibility: Buying a Nest Thermostat? Do This First #shorts
- 08_Short_smart_locks_for_airbnb_hosts: Airbnb Hosts: Why You Need a Smart Lock #shorts
- 09_Short_why_hire_a_pro_installer: Why Hire a Pro to Install Your Ring or Nest? #shorts
- 10_Short_Promo_Recent_Installs: Ring & Google Nest Installs in Northern Virginia #shorts
- 11_Short_AI_Installer_Clip: Professional Security Camera Installation #shorts
